package data.analyticCore;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Properties;
 
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

public class kfkProducer {
    
    public void sendMsg(String msg){
	   	 
        //Topic Name where logs message events need to publish
        String topicName = "test";
        // create instance for properties to access producer configs
        Properties props = new Properties();
 
        //Kafka server host and port
        props.put("bootstrap.servers", "192.168.2.179:9092");
 
        //Will receive acknowledgemnt of requests
        props.put("acks", "all");
 
       //Buffer size of events
        props.put("batch.size", 16384);
 
       //Total available buffer memory to the producer .
        props.put("buffer.memory", 33553333);
 
        //request less than zero
        props.put("linger.ms", 1);
 
        //If the request get fails, then retry again,
        props.put("retries", 0);
 
        props.put("key.serializer",
           "org.apache.kafka.common.serialization.StringSerializer");
 
        props.put("value.serializer",
           "org.apache.kafka.common.serialization.StringSerializer");
        
        //Thread.currentThread().setContextClassLoader(null);
        Producer<String, String> producer = new KafkaProducer
           <String, String>(props);

            producer.send(new ProducerRecord<String, String>(topicName, "message", msg));
        
                 System.out.println("All Messages sent successfully");
                 producer.close();
    }
}

