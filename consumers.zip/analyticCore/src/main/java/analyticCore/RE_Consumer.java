package analyticCore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.HashMap;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import analyticCore.DbPool;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public class RE_Consumer {
	public static void consumerRun(String topic) throws Exception{
		//Topics from where message need to consume
		List<String> topicsList=new ArrayList<String>();
		topicsList.add(topic);
		//topicsList.add("Topic2");        

		Properties props = new Properties();
		props.put("bootstrap.servers", "192.168.2.140:9092");
		props.put("group.id", "test");
		props.put("enable.auto.commit", "true");
		props.put("auto.commit.interval.ms", "1000");
		props.put("session.timeout.ms", "30000");
		props.put("key.deserializer",
				"org.apache.kafka.common.serialization.StringDeserializer");
		props.put("value.deserializer",
				"org.apache.kafka.common.serialization.StringDeserializer");
		KafkaConsumer<String, String> consumer = new KafkaConsumer
				<String, String>(props);

		//Kafka consumer subscribe to all these topics
		consumer.subscribe(topicsList);

		System.out.println("Subscribed to topic " + topicsList.get(0));


		while (true) {
			//Below poll setting will poll to kafka server in every 100 milliseconds
			//and get logs mssage from there
			ConsumerRecords<String, String> records = consumer.poll(100);
			for (ConsumerRecord<String, String> record : records)
			{
	             System.out.println(record.offset()+"-"+record.value());
	             DBintomysql(record.value());
			}
		}

	}
	public static void DBintomysql(String message) {  
		try {


			DbPool dbsql = new DbPool();
			HashMap<String, String> hmap = new HashMap<String, String>();
			hmap.put("SQL", message);


			HashMap2json(hmap);
			JSONObject obj  = HashMap2json(hmap);

			dbsql.SQLRun(obj);

		} catch (Throwable e) {  
			e.printStackTrace();  
		}
	}


	public static JSONObject HashMap2json(HashMap hmap) {
		return JSONObject.parseObject(JSON.toJSONString(hmap));
	}
}
