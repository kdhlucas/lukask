package analyticCore;

public class consumerMain {
	public static void main(String[] args) throws Exception {
		RE_Consumer REcon = new RE_Consumer();
		REcon.consumerRun("request_RE");
//		AM_Consumer AMcon = new AM_Consumer();
//		AMcon.consumerRun("request_AM");
	}
}
