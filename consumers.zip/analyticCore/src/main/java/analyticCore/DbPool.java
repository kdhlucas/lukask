package analyticCore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DbPool {
	  public static DbPool dbpool = null;
	  public static DruidDataSource druidDataSource = null;

	  public static final Logger log = LoggerFactory.getLogger(DbPool.class);
	  

	  static {
	    Properties pro = loadPropertiesFile("db_settings.properties");
	    try {
	      druidDataSource = (DruidDataSource) DruidDataSourceFactory.createDataSource(pro);
	    } catch (Exception e) {
	      log.warn(e.getMessage());
	    }
	  }

	  public DruidPooledConnection getConnection() {
	    try {
	      return druidDataSource.getConnection();
	    } catch (SQLException e) {
	    	log.warn(e.getMessage());
	    }
	    return null;
	  }
	  
	  

	  public static synchronized DbPool getInstance(){
	    if (null == dbpool) {
	      dbpool = new DbPool();
	    }
	    return dbpool;
	  }

	  public static Properties loadPropertiesFile(String filename) {
	    String webrootpath = null;
	     if (null == filename || filename.equals("")){
	       throw new IllegalArgumentException("Properties file path can not be null" + filename);
	       
	     }
	     webrootpath = DbPool.class.getClassLoader().getResource("").getPath();
	     webrootpath = new File(webrootpath).getParent();
	     InputStream input = null;
	     Properties p = null;
	     try {
	      input = new FileInputStream(new File(webrootpath+File.separator+"src"+File.separator+filename));
	      p = new Properties();
	      p.load(input);
	    } catch (FileNotFoundException e) {
	    	log.warn(e.getMessage());
	      input = DbPool.class.getResourceAsStream("/"+filename);
	      p = new Properties();
	      try {
	        p.load(input);
	      } catch (IOException e1) {
	    	  log.warn(e.getMessage());
	      }
	    } catch (IOException e) {
	    	log.warn(e.getMessage());
	    }
	     finally {
	       try {
	        input.close();
	      } catch (IOException e) {
	        e.printStackTrace();
	      }
	     }
	     return p;
	  }
	  
	  public JSONObject SQLRun(JSONObject json) {
	    String sql = json2sql(json);

	    log.info(sql); 
	    DbPool dbp = DbPool.getInstance(); 
	    DruidPooledConnection  conn = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    HashMap<String, Object> hmap = new HashMap<String, Object>();
	    try {
	      conn = dbp.getConnection();
	      pstmt = conn.prepareStatement(sql);
	      if (sql.toLowerCase().startsWith("select")) {
	        rs = pstmt.executeQuery();
	        int col = rs.getMetaData().getColumnCount();
	        ArrayList<Object> data_list = new ArrayList<Object>();
	        ArrayList<String> col_name = new ArrayList<String>();
	        for (int i = 1; i < col+1; i++) {
	          col_name.add(rs.getMetaData().getColumnName(i)) ;
	        }
	        while (rs.next()) {
	          ArrayList<Object> data = new ArrayList<Object>();
	          for (int i = 1; i < col+1; i++) {
	            data.add(rs.getString(i));
	          }
	          data_list.add(data);
	        }  
	        hmap.put("Data", data_list);
	        hmap.put("Count",data_list.size());
	        hmap.put("Field",col_name);
	      } 
	      else  {
	        int update_res = pstmt.executeUpdate();
	        hmap.put("Data", 0);
	        hmap.put("status", update_res);
	      }
	    } catch (Exception e) {
	    	log.warn(e.getMessage());
	        hmap.put("error", e.getMessage());
	    }
	    finally {
	      try {
	        if (pstmt != null) {
	          pstmt.close();
	        }
	        if (conn != null) {
	          conn.close();
	        }  
	      } catch (SQLException e) {
	    	  log.warn(e.getMessage());
	      }  
	    }
	    return HashMap2json(hmap);
	  }
	  
	  public static String getEncoding(String str) {  
	      String encode[] = new String[]{  
	              "UTF-8",  
	              "ISO-8859-1",  
	              "GB2312",  
	              "GBK",  
	              "GB18030",  
	              "Big5",  
	              "Unicode",  
	              "ASCII"  
	      };  
	      for (int i = 0; i < encode.length; i++){  
	          try {  
	              if (str.equals(new String(str.getBytes(encode[i]), encode[i]))) {  
	                  return encode[i];  
	              }  
	          } catch (Exception ex) {  
	          }  
	      }  
	        
	      return "";  
	  }  

	  public static String judgecharset(String sql) {
	    String charset = "UTF-8";
	    try {
	      return sql.equals(new String(sql.getBytes(charset),charset))?sql:URLDecoder.decode(sql,charset);
	    } catch (UnsupportedEncodingException e) {
	    	log.warn(e.getMessage());
	    }
	    return "";
	  }
	  
	    public static String json2sql(JSONObject json) {
	       return judgecharset(json.getString("SQL"));
	      }
	    
	  public static JSONObject HashMap2json(HashMap hmap) {
	    return JSONObject.parseObject(JSON.toJSONString(hmap));
	}
	  public void insert(String sql) throws SQLException {
	    DbPool dbp = DbPool.getInstance();  
	    DruidPooledConnection conn = null;
	    PreparedStatement ps = null;
	    try {
	      conn = dbp.getConnection();
	      ps = conn.prepareStatement(sql);
	      ps.executeUpdate();
	    } catch (SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	    }
	    finally {
	      ps.close();
	      conn.close();
	    }
	  }
	}
