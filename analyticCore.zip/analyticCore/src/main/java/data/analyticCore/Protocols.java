package data.analyticCore;

public class Protocols {


	private String RealtimeData;
	
	private String ProtocolName;
	
	private String Modbus_rtuData;
	
	private String Heartbeatdata;

	
	public String getRealtimeData() {
		// TODO Auto-generated method stub
		return RealtimeData;
	}
	public void setRealtimeData(String RealtimeData) {
		this.RealtimeData = RealtimeData;
	}

	public String getModbus_rtuData() {
		return Modbus_rtuData;
	}

	public void setModbus_rtuData(String modbus_rtuData) {
		Modbus_rtuData = modbus_rtuData;
	}
	public String getProtocolName() {
		return ProtocolName;
	}
	public void setProtocolName(String protocolName) {
		ProtocolName = protocolName;
	}
	
	public String getHeartbeatdata() {
		// TODO Auto-generated method stub
		return Heartbeatdata;
	}
	
	public void setHeartbeatdata(String Heartbeatdata) {
		
		this.Heartbeatdata = Heartbeatdata;
	}

	
}
