package data.analyticCore;

public class Machines {

	private String MachData;
	
	private String RealtimeData;
	
	
	public String getMachData() {
		return MachData;
	}

	public void setMachData(String machData) {
		this.MachData = machData;
	}

	public String getRealtimeData() {
		// TODO Auto-generated method stub
		return RealtimeData;
	}
	public void setRealtimeData(String RealtimeData) {
		this.RealtimeData = RealtimeData;
	}

}
