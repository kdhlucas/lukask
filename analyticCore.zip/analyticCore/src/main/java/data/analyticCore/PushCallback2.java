package data.analyticCore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;  
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import com.google.gson.Gson;  

public class PushCallback2 implements MqttCallback {
	public void connectionLost(Throwable cause) {  
        // 连接丢失后，一般在这里面进行重连  
        System.out.println("连接断开，可以做重连");  
    }  

    public void deliveryComplete(IMqttDeliveryToken token) {  
        System.out.println("deliveryComplete---------" + token.isComplete());  
    }  

    public void messageArrived(String topic, MqttMessage message) throws Exception {  
        // subscribe后得到的消息会执行到这里面  
//        System.out.println("接收消息主题 : " + topic);  
//        System.out.println("接收消息Qos : " + message.getQos());  
//        System.out.println("接收消息内容 : " + new String(message.getPayload())); 
        RulesEngine(new String(message.getPayload()));
    }
    
    public static void RulesEngine(String message){  

//      System.out.println("处理json中的数据 : " + dataList); 
        
        try {
            // load up the knowledge base
            KnowledgeBase kbase = readKnowledgeBase();
            StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
            Variables var = new Variables();//创建一个数组
            
            Gson gson = new Gson();
            Map<String, Object> map = new HashMap<String, Object>();
            map = gson.fromJson(message, map.getClass());
            ArrayList dataList=(ArrayList) map.get("values");
            System.out.println("map的值为:"+dataList.toString());
            
            for( int i = 0 ; i < dataList.size() ; i++) {//内部不锁定，效率最高，但在多线程要考虑并发操作的问题。
                System.out.println(dataList.get(i));
                Map dataDict = (Map) dataList.get(i);
//                System.out.println("处理数据:"+dataDict.get("data").toString());
                String a = dataDict.get("name").toString();
                if (a.equals("工作油温度")) {
                  //System.out.println("处理工作油温度值:"+dataDict.get("data").toString());
                  var.setTemperature(Integer.parseInt(dataDict.get("data").toString()));
                }else if(a.equals("冷却油压力")){
                  //System.out.println("处理冷却油压力值:"+dataDict.get("data").toString());
                  var.setPressure(Integer.parseInt(dataDict.get("data").toString()));
                }else if(a.equals("流速")){
                  //System.out.println("处理流速值:"+dataDict.get("data").toString());
                  var.setSpeed(Integer.parseInt(dataDict.get("data").toString()));
                }else if(a.equals("液位")){
                  //System.out.println("处理液位值:"+dataDict.get("data").toString());
                  var.setLevel(Integer.parseInt(dataDict.get("data").toString()));
                }else{
                  //System.out.println("无法处理该数据");
                }
            }
//            Variables var = new Variables();
//            var.setTemperature(0);
//            var.setPressure(0);
//            var.setSpeed(0);
//            var.setLevel(0);
//            ksession.insert(var);
            
//            AlarmModules alarm = new AlarmModules();
//            alarm.setCode("2000");
            ksession.insert(var);
            ksession.fireAllRules();
            String mStatus = var.getMachineStatus();
            System.out.println("Machine Status: " + mStatus);
//            System.out.println("Code Message: " + alarm.getMessage());
            
            kfkProducer kfkP = new kfkProducer();
            kfkP.sendMsg(mStatus);
            
        } catch (Throwable t) {
            t.printStackTrace();
        }
        
        
    }
	
    private static KnowledgeBase readKnowledgeBase() throws Exception {
    	
        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
        
        kbuilder.add(ResourceFactory.newClassPathResource("Variables.drl"), ResourceType.DRL);
        //kbuilder.add(ResourceFactory.newClassPathResource("Alarm.drl"), ResourceType.DRL);

        
        KnowledgeBuilderErrors errors = kbuilder.getErrors();
        
        if (errors.size() > 0) {
            for (KnowledgeBuilderError error: errors) {
                System.err.println(error);
            }
            throw new IllegalArgumentException("Could not parse knowledge.");
        }
        
        KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
        
        return kbase;
    }
    
}
