package data.analyticCore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class kfkConsumer {
	public static void main(String[] args) {
	    //Topics from where message need to consume
	     List<String> topicsList=new ArrayList<String>();
	     topicsList.add("RealtimeData");
	     //topicsList.add("Topic2");        

	      Properties props = new Properties();
//	      props.put("bootstrap.servers", "localhost:9092");
//	      props.put("bootstrap.servers", "172.17.0.7:9092");
	      props.put("bootstrap.servers", "192.168.2.140:9092");
	      props.put("group.id", "RealtimeData");
	      props.put("enable.auto.commit", "true");
	      props.put("auto.commit.interval.ms", "1000");
	      props.put("session.timeout.ms", "30000");
	      props.put("key.deserializer",
	         "org.apache.kafka.common.serialization.StringDeserializer");
	      props.put("value.deserializer",
	         "org.apache.kafka.common.serialization.StringDeserializer");
	      KafkaConsumer<String, String> consumer = new KafkaConsumer
	         <String, String>(props);

	      //Kafka consumer subscribe to all these topics
	      consumer.subscribe(topicsList);

	      System.out.println("Subscribed to topic " + topicsList.get(0));
	      

	      while (true) {
	         //Below poll setting will poll to kafka server in every 100 milliseconds
	         //and get logs mssage from there
	         ConsumerRecords<String, String> records = consumer.poll(100);
	         for (ConsumerRecord<String, String> record : records)
	         {
	            //Print offset value of Kafka partition where logs message store and value for it
	             System.out.println(record.offset()+"-"+record.value());
	             DBintomysql(record.value());
	         }
	      }

	}
//	;  
//    static DBHelper db1 = null;
	
	public static void DBintomysql(String message) {  
        try {

        	
            DbPool dbsql = new DbPool();
            HashMap<String, String> hmap = new HashMap<String, String>();
            hmap.put("SQL", message);
            
            
            HashMap2json(hmap);
            JSONObject obj  = HashMap2json(hmap);
            
            dbsql.SQLRun(obj);
//            System.out.println("查询到的topic列表为 : " + sadf);
            //db1 = new DBHelper(sql);//创建DBHelper对象  
                //ret = db1.pst.executeUpdate();//执行语句，得到结果集  
                //ret.close();  
                //db1.close();//关闭连接  
            } catch (Throwable e) {  
                e.printStackTrace();  
            }
    }

	
	public static JSONObject HashMap2json(HashMap hmap) {
		//alibaba��fastjson����java��������ǿ��json��
		return JSONObject.parseObject(JSON.toJSONString(hmap));
}
	//重启mqtt client
	
}
