package data.analyticCore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;  
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import com.alibaba.fastjson.*;
import com.google.gson.Gson;  

public class PushCallback implements MqttCallback {
	public void connectionLost(Throwable cause) {  
        // 连接丢失后，一般在这里面进行重连  
        System.out.println("连接断开，可以做重连");  
    }  

    public void deliveryComplete(IMqttDeliveryToken token) {  
        System.out.println("deliveryComplete---------" + token.isComplete());  
    }  

    public void messageArrived(String topic, MqttMessage message) throws Exception {  
        // subscribe后得到的消息会执行到这里面  
//        System.out.println("接收消息主题 : " + topic);  
//        System.out.println("接收消息Qos : " + message.getQos());  
//        System.out.println("接收消息内容 : " + new String(message.getPayload())); 
        RulesEngine(new String(message.getPayload()),topic);
    }
    

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void RulesEngine(String message,String topic){ 
        try {
            // load up the knowledge base
            KnowledgeBase kbase = readKnowledgeBase();
            StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
            
            Gson gson = new Gson();
            Map<String, Object> map = new HashMap<String, Object>();
            map = gson.fromJson(message, map.getClass());
            ArrayList dataList=(ArrayList) map.get("values");
            System.out.println("接收消息的payload:"+dataList.toString());
            System.out.println("接收消息的topic : " + topic);
            //处理topic字符串
            String[] array = topic.split("/");
            
            for( int i = 0 ; i < dataList.size() ; i++) {//内部不锁定，效率最高，但在多线程要考虑并发操作的问题。
            	Machines var = new Machines();
            	Protocols Protocols = new Protocols();
            	String fieldnames = ""; 
            	String fieldvalues = ""; 
            	String tablename = "";
            	Map<String, String> newdict = new HashMap<String, String>();
            	String sql = null;  
            	kfkProducer kfkP = new kfkProducer();
            	
            	
            	Map<String, String> dataDict = (Map<String, String>) dataList.get(i);
                dataDict.put("compID",array[0]);
                dataDict.put("gateMac", array[1]);
                dataDict.put("dataType", array[3]);
                dataDict.put("Protocol", array[array.length-1]);
                
                dataDict.put("MachID", "1");
                dataDict.put("operationFlag", "9");
                
                var.setMachData(dataDict.toString());
                System.out.println("传入规则引擎:"+var.getMachData());
//                String a = dataDict.get("name").toString();
//                System.out.println("Machine newModbus_rtuData: " + a);
                

                //获取每个变量的实时数据
                ksession.insert(var);
                ksession.fireAllRules();
                String RealtimeData = var.getRealtimeData();
                System.out.println("Machine RealtimeData: " + RealtimeData);
                System.out.println("Protocolname: " + array[array.length-1]);
                
//                kfkP.sendMsg(RealtimeData);
                
                //获取对应工业协议的实时数据Modbus_rtuData
                Protocols.setRealtimeData(RealtimeData);
                Protocols.setProtocolName(array[array.length-1]);
                
                ksession.insert(Protocols);
                ksession.fireAllRules();
                String MODBUS_RTUdata = Protocols.getModbus_rtuData();
                String Heartbeat_data = Protocols.getHeartbeatdata();
                
                System.out.println("Machine Modbus_rtuData: " + MODBUS_RTUdata);
                System.out.println("gateway HeartbeatData: " + Heartbeat_data);
                
                //获取工业协议实时数据每条值，用规则引擎对字段进行重新组装
                //Modbus_rtu.setModbus_rtuData(MODBUS_RTUdata);
                //string to map
                Map<String, String> MODBUS_RTUdict = (Map<String, String>) getValue(MODBUS_RTUdata);
                System.out.println("Modbus_rtu字典格式: " + MODBUS_RTUdict); 
                //遍历MODBUS_RTUdata获取每个key value,传入RE进行判断改值
                for(Map.Entry<String, String> entry : MODBUS_RTUdict.entrySet()){
//                	 System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
                	 
                	 Modbus_rtu Modbus_rtu = new Modbus_rtu();
                	 Modbus_rtu.setVariableName(entry.getKey());
                	 
                	 ksession.insert(Modbus_rtu);
                     ksession.fireAllRules();
                     

                     @SuppressWarnings("unused")
					String VariableName = Modbus_rtu.getVariableName();
//                     System.out.println("Machine VariableName: " + VariableName);
                     String newVariableName = Modbus_rtu.getNewVariableName();
//                     System.out.println("Machine newVariableName: " + newVariableName);
                     
                     
                     //delete会被覆盖，只剩一个
                	 newdict.put(newVariableName,entry.getValue());                  
                }
                //过滤删除 delete 字段
                newdict = deleteKeyOfMap(newdict);
                
                //处理gatherTime
                String a = newdict.get("gatherTime").toString();
                a = a.substring(0, 10)+" "+a.substring(10,18);
                newdict.put("gatherTime", a);
                
                System.out.println("Machine newdict: " + newdict.toString());
                //resultdata接口    heartbeat and rasultdata
                
                
                
                //拼接sql
                for(Map.Entry<String, String> entry : newdict.entrySet()){
//               	 System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
                	
               	fieldnames = fieldnames + entry.getKey()  +",";
                fieldvalues = fieldvalues + "'" + entry.getValue() + "'" +",";
               	 
                }
                
                
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
                
//                System.out.println("Machine fieldnames: " + fieldnames);
//                System.out.println("Machine fieldvalues: " + fieldvalues);  
                Date day=new Date();
                tablename = "dac_equipmentdata_" + a.substring(0,4)+ a.substring(5,7)+ a.substring(8,10);
                
                sql = "create table if not EXISTS " + tablename + " like dac_equipmentdata";
                
                
                kfkP.sendMsg(sql);
                		
                sql = "Insert Into  "+ tablename +" (" + fieldnames + "createTime) Values (" + fieldvalues + "'"+df.format(day) + "')";
                kfkP.sendMsg(sql);
                
            }
            

        } catch (Throwable t) {
            t.printStackTrace();
        }
        
        
    }
	
    private static KnowledgeBase readKnowledgeBase() throws Exception {
    	
        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
        
        kbuilder.add(ResourceFactory.newClassPathResource("RealtimeData.drl"), ResourceType.DRL);
//        kbuilder.add(ResourceFactory.newClassPathResource("ProtocolData.drl"), ResourceType.DRL);

        
        KnowledgeBuilderErrors errors = kbuilder.getErrors();
        
        if (errors.size() > 0) {
            for (KnowledgeBuilderError error: errors) {
                System.err.println(error);
            }
            throw new IllegalArgumentException("Could not parse knowledge.");
        }
        
        KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
        
        return kbase;
    }
    
    public static Object getValue(String param) {
        Map map = new HashMap();
        String str = "";
        String key = "";
        Object value = "";
        char[] charList = param.toCharArray();
        boolean valueBegin = false;
        for (int i = 0; i < charList.length; i++) {
            char c = charList[i];
            if (c == '{') {
                if (valueBegin == true) {
                    value = getValue(param.substring(i, param.length()));
                    i = param.indexOf('}', i) + 1;
                    map.put(key, value);
                }
            } else if (c == '=') {
                valueBegin = true;
                key = str;
                str = "";
            } else if (c == ',') {
                valueBegin = false;
                value = str;
                str = "";
                map.put(key, value);
            } else if (c == '}') {
                if (str != "") {
                    value = str;
                }
                map.put(key, value);
                return map;
            } else if (c != ' ') {
                str += c;
            }
        }
        return map;
    }
    
    private static Map<String, String> deleteKeyOfMap(Map<String, String> newdict){
        System.out.println("=====删除前=====\n"+newdict);
        Iterator<String> iter = newdict.keySet().iterator();
        while(iter.hasNext()){
            String key = iter.next();
            if(key.equals("delete")){
                iter.remove();
            }
        }
        System.out.println("=====删除后=====\n"+newdict);
        return newdict;
    }
    
    
    
}
