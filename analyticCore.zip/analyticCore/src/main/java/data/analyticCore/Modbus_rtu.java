package data.analyticCore;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Modbus_rtu {


	
	private String Modbus_rtuData;
	
	private String Modbus_rtuDatanew;
	
	private String VariableName;
	
	private String newVariableName;
	
	private Map dataDict;
	
	private Map newdataDict;
	
	
	public String getModbus_rtuData() {
		return Modbus_rtuData;
	}

	public void setModbus_rtuData(String modbus_rtuData) {
		Modbus_rtuData = modbus_rtuData;
	}

	public String getModbus_rtuDatanew() {
		return Modbus_rtuDatanew;
	}

	public void setModbus_rtuDatanew(String modbus_rtuDatanew) {
		Modbus_rtuDatanew = modbus_rtuDatanew;
	}

	public String getVariableName() {
		
		return VariableName;
	}
	
	public void setVariableName(String VariableName) {
//		VariableName = newdict.keySet();
		this.VariableName = VariableName;
		//System.out.println("key为: " + VariableName);
	}
	
	
	public Map getDataDict() {
		return dataDict;
	}
	
	public void setDataDict(Map dataDict) {
		this.dataDict = dataDict;
	}
	
	public Map getNewdataDict() {
		return newdataDict;
	}
	public void setNewdataDict(Map newdataDict) {
		this.newdataDict = newdataDict;
	}

	public String getNewVariableName() {
		return newVariableName;
	}

	public void setNewVariableName(String newVariableName) {
		this.newVariableName = newVariableName;
		//System.out.println("规则引擎赋值  为: " +newVariableName);
	}




}
