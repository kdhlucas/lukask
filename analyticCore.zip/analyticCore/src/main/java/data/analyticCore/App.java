package data.analyticCore;

import java.io.*;

/**
 * Hello world!
 *
 */
public class App
{
    public static void main( String[] args )
    {
        try{

                System.out.println( "Hello World!" );
                FileWriter fstream = new FileWriter("out.txt");
                BufferedWriter out = new BufferedWriter(fstream);
                out.write("Hello Java");
                out.close();
        }catch (Exception e){
                System.err.println("Error: " + e.getMessage());
        }
    }
}
