package data.analyticCore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public class kfkConsumer {
	public static void main(String[] args) {
	    //Topics from where message need to consume
	     List<String> topicsList=new ArrayList<String>();
	     topicsList.add("test");
	     //topicsList.add("Topic2");        

	      Properties props = new Properties();
	      props.put("bootstrap.servers", "localhost:9092");
	      props.put("group.id", "test");
	      props.put("enable.auto.commit", "true");
	      props.put("auto.commit.interval.ms", "1000");
	      props.put("session.timeout.ms", "30000");
	      props.put("key.deserializer",
	         "org.apache.kafka.common.serialization.StringDeserializer");
	      props.put("value.deserializer",
	         "org.apache.kafka.common.serialization.StringDeserializer");
	      KafkaConsumer<String, String> consumer = new KafkaConsumer
	         <String, String>(props);

	      //Kafka consumer subscribe to all these topics
	      consumer.subscribe(topicsList);

	      System.out.println("Subscribed to topic " + topicsList.get(0));
	      

	      while (true) {
	         //Below poll setting will poll to kafka server in every 100 milliseconds
	         //and get logs mssage from there
	         ConsumerRecords<String, String> records = consumer.poll(100);
	         for (ConsumerRecord<String, String> record : records)
	         {
	            //Print offset value of Kafka partition where logs message store and value for it
	             System.out.println(record.offset()+"-"+record.value());
	             DBintomysql(record.value());
	         }
	      }

	}
	static String sql = null;  
    static DBHelper db1 = null;
	
	public static void DBintomysql(String message) {  
        try {
          Date day=new Date();    
          SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
            sql = "insert into machstatus(status,gatherTime) values('"+message+"','"+df.format(day)+"')";
            db1 = new DBHelper(sql);//创建DBHelper对象  
                //ret = db1.pst.executeUpdate();//执行语句，得到结果集  
                
  
                //ret.close();  
                db1.close();//关闭连接  
            } catch (Throwable e) {  
                e.printStackTrace();  
            }
    }  
}
